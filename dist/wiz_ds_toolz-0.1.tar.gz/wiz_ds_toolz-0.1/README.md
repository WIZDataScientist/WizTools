# Example from
https://github.com/BillMills/python-package-example

# Wrap it and Ship it
python setup.py sdist