# Example from
https://github.com/BillMills/python-package-example

# Wrap it and Ship it
python setup.py sdist

# Handy notebook trick
https://medium.com/@dustinmichels/three-handy-jupyter-notebook-snippets-dcb2f8ddc7db